const STORAGE_KEY = "sms_demo_students_v1";
let students = loadStudents();
let editingId = null;

const form = document.getElementById("studentForm");
const tableBody = document.getElementById("studentTable");
const searchInput = document.getElementById("searchInput");
const message = document.getElementById("formMessage");

function loadStudents() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
  } catch {
    return [];
  }
}

function saveStudents() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(students));
}

function showMessage(text, isError = false) {
  message.textContent = text;
  message.style.color = isError ? "#b42318" : "#167044";
}

function renderStudents() {
  const query = searchInput.value.trim().toLowerCase();
  const filtered = students.filter(student =>
    [student.fullName, student.admission, student.course, student.email]
      .some(value => value.toLowerCase().includes(query))
  );

  tableBody.replaceChildren();
  document.getElementById("emptyState").hidden = filtered.length > 0;

  filtered.forEach(student => {
    const row = document.createElement("tr");
    [student.fullName, student.admission, student.email || "—", student.course, student.year]
      .forEach(value => {
        const cell = document.createElement("td");
        cell.textContent = value;
        row.appendChild(cell);
      });

    const actions = document.createElement("td");
    const editButton = document.createElement("button");
    editButton.className = "button secondary";
    editButton.textContent = "Edit";
    editButton.type = "button";
    editButton.addEventListener("click", () => beginEdit(student.id));

    const deleteButton = document.createElement("button");
    deleteButton.className = "button danger";
    deleteButton.textContent = "Delete";
    deleteButton.type = "button";
    deleteButton.addEventListener("click", () => removeStudent(student.id));

    actions.append(editButton, deleteButton);
    row.appendChild(actions);
    tableBody.appendChild(row);
  });

  document.getElementById("totalStudents").textContent = students.length;
  document.getElementById("totalCourses").textContent = new Set(students.map(s => s.course)).size;
}

form.addEventListener("submit", event => {
  event.preventDefault();
  const record = {
    id: editingId || (crypto.randomUUID ? crypto.randomUUID() : String(Date.now())),
    fullName: document.getElementById("fullName").value.trim(),
    admission: document.getElementById("admission").value.trim(),
    email: document.getElementById("email").value.trim(),
    course: document.getElementById("course").value,
    year: document.getElementById("year").value
  };

  const duplicate = students.some(student =>
    student.admission.toLowerCase() === record.admission.toLowerCase() &&
    student.id !== editingId
  );
  if (duplicate) {
    showMessage("That admission number is already registered.", true);
    return;
  }

  if (editingId) {
    students = students.map(student => student.id === editingId ? record : student);
    showMessage("Student record updated.");
  } else {
    students.push(record);
    showMessage("Student registered successfully.");
  }

  saveStudents();
  resetForm();
  renderStudents();
});

function beginEdit(id) {
  const student = students.find(item => item.id === id);
  if (!student) return;
  editingId = id;
  document.getElementById("fullName").value = student.fullName;
  document.getElementById("admission").value = student.admission;
  document.getElementById("email").value = student.email;
  document.getElementById("course").value = student.course;
  document.getElementById("year").value = student.year;
  document.getElementById("formHeading").textContent = "Edit student";
  document.getElementById("saveButton").textContent = "Save changes";
  document.getElementById("cancelButton").hidden = false;
  document.getElementById("fullName").focus();
}

function resetForm() {
  form.reset();
  editingId = null;
  document.getElementById("formHeading").textContent = "Register a student";
  document.getElementById("saveButton").textContent = "Add student";
  document.getElementById("cancelButton").hidden = true;
}

function removeStudent(id) {
  const student = students.find(item => item.id === id);
  if (!student || !confirm(`Delete the record for ${student.fullName}?`)) return;
  students = students.filter(item => item.id !== id);
  saveStudents();
  renderStudents();
  showMessage("Student record deleted.");
}

document.getElementById("cancelButton").addEventListener("click", () => {
  resetForm();
  showMessage("Edit cancelled.");
});
searchInput.addEventListener("input", renderStudents);
renderStudents();
