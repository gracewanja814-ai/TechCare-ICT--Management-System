# Student Management System

A beginner-friendly student records application built with HTML, CSS and JavaScript.

## Features
- Add student records
- View all saved records
- Search by student name, admission number, email or course
- Edit student records
- Delete student records
- Dashboard counts for students and courses
- Responsive layout for phones and computers
- Browser local storage persistence

## How to run
1. Download or clone this repository.
2. Open `index.html` in a modern web browser.
3. Add sample student records using the form.

No installation or server is required.

## Files
- `index.html` — page structure
- `style.css` — design and responsive layout
- `script.js` — student record functionality

## Important limitation
This is an educational demo. Records are stored only in the current browser on the current device. It does not use a shared database, user login, or server-side security. Do not enter real or sensitive student information.

## Future improvements
- Add a secure backend and database
- Add administrator login and role-based access
- Add student results and attendance modules
- Add CSV export and printable reports

## Author
Student ICT Portfolio Project — 2026
