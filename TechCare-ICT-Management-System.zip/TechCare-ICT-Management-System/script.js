const STORAGE_KEY = "techcare-demo-v1";
const starterData = {
  computers: [
    {id:1,name:"Reception Desktop",serial:"TC-1001",department:"Administration",type:"Desktop"},
    {id:2,name:"IT Support Laptop",serial:"TC-1002",department:"ICT",type:"Laptop"},
    {id:3,name:"Accounts Printer",serial:"TC-1003",department:"Finance",type:"Printer"}
  ],
  tickets: [
    {id:1,reporter:"Mary",device:"Reception Desktop",category:"Hardware",priority:"Normal",description:"Keyboard keys are not responding.",status:"Pending",date:new Date().toLocaleDateString()},
    {id:2,reporter:"James",device:"IT Support Laptop",category:"Software",priority:"High",description:"Operating system update required.",status:"In Progress",date:new Date().toLocaleDateString()}
  ],
  maintenance: [
    {id:1,device:"Accounts Printer",date:new Date().toISOString().slice(0,10),activity:"Cleaning",technician:"ICT Support",details:"External cleaning and test print completed."}
  ]
};
let data;
try { data = JSON.parse(localStorage.getItem(STORAGE_KEY)) || starterData; }
catch { data = starterData; }
const $ = (id) => document.getElementById(id);
const save = () => localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
const escapeHTML = (value) => String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const emptyRow = (cols, message) => `<tr><td colspan="${cols}" class="empty">${message}</td></tr>`;
function showSection(name) {
  document.querySelectorAll(".page-section").forEach(s => s.classList.toggle("active", s.id === name));
  document.querySelectorAll(".nav-link").forEach(a => a.classList.toggle("active", a.dataset.section === name));
  const link = document.querySelector(`[data-section="${name}"]`);
  $("pageTitle").textContent = link ? link.textContent.trim().replace(/^[▦▣▤⚙ⓘ]\s*/, "") : "Dashboard";
  $("sidebar").classList.remove("open");
  location.hash = name;
}
document.querySelectorAll("[data-section]").forEach(a => a.addEventListener("click", e => {e.preventDefault();showSection(a.dataset.section);}));
document.querySelectorAll("[data-go]").forEach(b => b.addEventListener("click", () => showSection(b.dataset.go)));
$("menuBtn").addEventListener("click", () => $("sidebar").classList.toggle("open"));
$("today").textContent = new Intl.DateTimeFormat("en-KE",{day:"numeric",month:"short",year:"numeric"}).format(new Date());

function renderDashboard() {
  $("totalComputers").textContent = data.computers.length;
  $("openTickets").textContent = data.tickets.filter(t => t.status !== "Resolved").length;
  $("resolvedTickets").textContent = data.tickets.filter(t => t.status === "Resolved").length;
  $("maintenanceCount").textContent = data.maintenance.length;
  const recent = [...data.tickets].slice(-5).reverse();
  $("recentTickets").innerHTML = recent.length ? `<table><thead><tr><th>Issue</th><th>Device</th><th>Status</th></tr></thead><tbody>${recent.map(t=>`<tr><td>${escapeHTML(t.category)}</td><td>${escapeHTML(t.device)}</td><td><span class="status ${t.status.replace(" ","-")}">${escapeHTML(t.status)}</span></td></tr>`).join("")}</tbody></table>` : `<p class="empty">No support tickets yet.</p>`;
}
function renderComputers(filter="") {
  const rows = data.computers.filter(c => Object.values(c).join(" ").toLowerCase().includes(filter.toLowerCase()));
  $("computerList").innerHTML = `<table><thead><tr><th>Device</th><th>Serial number</th><th>Department</th><th>Type</th><th>Action</th></tr></thead><tbody>${rows.length ? rows.map(c=>`<tr><td><b>${escapeHTML(c.name)}</b></td><td>${escapeHTML(c.serial)}</td><td>${escapeHTML(c.department)}</td><td>${escapeHTML(c.type)}</td><td><button class="table-action" data-delete-computer="${c.id}">Delete</button></td></tr>`).join("") : emptyRow(5,"No matching computers.")}</tbody></table>`;
}
function renderTickets(filter="") {
  const rows = data.tickets.filter(t => Object.values(t).join(" ").toLowerCase().includes(filter.toLowerCase()));
  $("ticketList").innerHTML = `<table><thead><tr><th>Ticket</th><th>Device / issue</th><th>Priority</th><th>Status</th><th>Update</th></tr></thead><tbody>${rows.length ? rows.map(t=>`<tr><td>#${t.id}<br><small>${escapeHTML(t.date)}</small></td><td><b>${escapeHTML(t.device)}</b><br><small>${escapeHTML(t.category)} · ${escapeHTML(t.description)}</small></td><td>${escapeHTML(t.priority)}</td><td><span class="status ${t.status.replace(" ","-")}">${escapeHTML(t.status)}</span></td><td><select class="table-action" data-status="${t.id}" aria-label="Update ticket status"><option ${t.status==="Pending"?"selected":""}>Pending</option><option ${t.status==="In Progress"?"selected":""}>In Progress</option><option ${t.status==="Resolved"?"selected":""}>Resolved</option></select></td></tr>`).join("") : emptyRow(5,"No tickets found.")}</tbody></table>`;
}
function renderMaintenance() {
  const rows = [...data.maintenance].reverse();
  $("maintenanceList").innerHTML = `<table><thead><tr><th>Date</th><th>Device</th><th>Activity</th><th>Technician</th><th>Details</th></tr></thead><tbody>${rows.length ? rows.map(m=>`<tr><td>${escapeHTML(m.date)}</td><td>${escapeHTML(m.device)}</td><td>${escapeHTML(m.activity)}</td><td>${escapeHTML(m.technician)}</td><td>${escapeHTML(m.details)}</td></tr>`).join("") : emptyRow(5,"No maintenance records yet.")}</tbody></table>`;
}
function renderAll(){renderDashboard();renderComputers($("computerSearch").value);renderTickets($("ticketSearch").value);renderMaintenance();}
$("computerForm").addEventListener("submit", e => {
  e.preventDefault(); const f = new FormData(e.target);
  if(data.computers.some(c=>c.serial.toLowerCase()===f.get("serial").trim().toLowerCase())) return alert("That serial number is already registered.");
  data.computers.push({id:Date.now(),name:f.get("name").trim(),serial:f.get("serial").trim(),department:f.get("department").trim(),type:f.get("type")});
  save();e.target.reset();renderAll();alert("Computer added to inventory.");
});
$("ticketForm").addEventListener("submit", e => {
  e.preventDefault();const f=new FormData(e.target);
  data.tickets.push({id:Date.now(),reporter:f.get("reporter").trim(),device:f.get("device").trim(),category:f.get("category"),priority:f.get("priority"),description:f.get("description").trim(),status:"Pending",date:new Date().toLocaleDateString()});
  save();e.target.reset();renderAll();alert("Support ticket submitted.");
});
$("maintenanceForm").addEventListener("submit", e => {
  e.preventDefault();const f=new FormData(e.target);
  data.maintenance.push({id:Date.now(),device:f.get("device").trim(),date:f.get("date"),activity:f.get("activity"),technician:f.get("technician").trim(),details:f.get("details").trim()});
  save();e.target.reset();renderAll();alert("Maintenance record saved.");
});
$("computerList").addEventListener("click", e => {
  const id=Number(e.target.dataset.deleteComputer);if(!id)return;
  if(confirm("Delete this computer from the demo inventory?")){data.computers=data.computers.filter(c=>c.id!==id);save();renderAll();}
});
$("ticketList").addEventListener("change", e => {
  const id=Number(e.target.dataset.status);if(!id)return;
  const ticket=data.tickets.find(t=>t.id===id);if(ticket){ticket.status=e.target.value;save();renderAll();}
});
$("computerSearch").addEventListener("input",e=>renderComputers(e.target.value));
$("ticketSearch").addEventListener("input",e=>renderTickets(e.target.value));
const initialSection = location.hash.slice(1);
if(["dashboard","computers","tickets","maintenance","guides"].includes(initialSection)) showSection(initialSection);
renderAll();
