# TechCare ICT Management System

TechCare is a beginner-friendly ICT portfolio project built with HTML, CSS and vanilla JavaScript. It demonstrates how an organisation could organise computer equipment, record support requests and document maintenance work.

## Features

- Dashboard with live counts for devices, open tickets, resolved tickets and maintenance logs.
- Computer inventory: add, search and delete devices.
- Help desk: report issues, search tickets and update ticket status.
- Maintenance log: record service activities.
- ICT support guides covering common troubleshooting and cybersecurity practices.
- Responsive layout for desktop and mobile screens.
- Browser local storage so demo records remain after refreshing the page on the same browser/device.

## Technologies

- HTML5
- CSS3
- JavaScript (no framework or build tools)

## Run the project

1. Download or clone this repository.
2. Open `index.html` in a modern web browser.
3. Try adding a computer, submitting a ticket and recording maintenance.

## Important demo limitations

This is a front-end demonstration. It does not have user accounts, access controls, a server or a shared database. Data is stored only in the browser's local storage on the device being used. Do not enter real personal, confidential or company information. A production system would need a secure backend, authentication, authorisation, validation and database backups.

## Future improvements

- Add a secure backend and database.
- Add staff login and role-based permissions.
- Export inventory and maintenance reports.
- Add ticket assignment and due dates.
- Add audit logs and data backup.

## Author

Created as an IT student learning project. Update this section with your name and GitHub profile before publishing.
